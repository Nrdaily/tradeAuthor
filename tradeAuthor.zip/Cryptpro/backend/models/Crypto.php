<?php
class Crypto {
    private $conn;
    private $table_name = "cryptocurrencies";

    public $id;
    public $symbol;
    public $name;
    public $current_price;
    public $icon_url;
    public $is_active;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = "SELECT id, symbol, name, current_price, icon_url
                FROM " . $this->table_name . "
                WHERE is_active = 1
                ORDER BY symbol";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }
}
?>