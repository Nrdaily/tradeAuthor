<?php
class TransactionController {
    private $conn;
    private $table_name = "transactions";
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($user_id, $crypto_id, $type, $amount, $usd_value, $fee = 0, $related_address = null) {
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    user_id = :user_id,
                    crypto_id = :crypto_id,
                    type = :type,
                    amount = :amount,
                    usd_value = :usd_value,
                    fee = :fee,
                    related_address = :related_address,
                    status = 'pending'";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':crypto_id', $crypto_id);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':usd_value', $usd_value);
        $stmt->bindParam(':fee', $fee);
        $stmt->bindParam(':related_address', $related_address);
        
        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        
        return false;
    }
    
    public function updateStatus($transaction_id, $status) {
        $query = "UPDATE " . $this->table_name . "
                SET status = :status
                WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $transaction_id);
        
        return $stmt->execute();
    }
    
    public function getUserTransactions($user_id) {
        $query = "SELECT t.*, c.symbol, c.name 
                FROM " . $this->table_name . " t
                LEFT JOIN cryptocurrencies c ON t.crypto_id = c.id
                WHERE t.user_id = :user_id
                ORDER BY t.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt;
    }
}
?>