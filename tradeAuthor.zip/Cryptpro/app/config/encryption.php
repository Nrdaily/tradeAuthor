<?php
define('ENCRYPTION_KEY', '%2025^TrAdE77!71@89#976$321+PrO&');