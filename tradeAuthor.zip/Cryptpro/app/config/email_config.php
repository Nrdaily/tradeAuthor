
<?php
// Email Configuration for Trade Author
return [
    // SMTP Configuration
    'smtp_host' => 'premium279.web-hosting.com',
    'smtp_port' => 465,
    'smtp_username' => 'verify@tradeauthor.com',
    'smtp_password' => 'blEi4mI62_JF',
    'from_email' => 'verify@tradeauthor.com',
    'from_name' => 'Trade Author',
    
    // Alternative SMTP providers (uncomment and configure as needed)
    
    // For SendGrid
    // 'smtp_host' => 'smtp.sendgrid.net',
    // 'smtp_port' => 587,
    // 'smtp_username' => 'apikey',
    // 'smtp_password' => 'your-sendgrid-api-key',
    
    // For Mailgun
    // 'smtp_host' => 'smtp.mailgun.org',
    // 'smtp_port' => 587,
    // 'smtp_username' => 'postmaster@your-domain.com',
    // 'smtp_password' => 'your-mailgun-password',
    
    // For Office 365
    // 'smtp_host' => 'smtp.office365.com',
    // 'smtp_port' => 587,
    // 'smtp_username' => 'your-email@your-domain.com',
    // 'smtp_password' => 'your-password',
];
?>